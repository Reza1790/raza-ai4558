package com.raza.aiassistant

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    var editing by remember { mutableStateOf<Provider?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Provider?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    Box(Modifier.fillMaxSize().background(appBackground())) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text("Settings", fontWeight = FontWeight.Bold) },
                    navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { pad ->
            Column(
                Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Section("API providers & keys") {
                    if (vm.providers.isEmpty()) Text("No providers yet. Add Gemini, OpenAI, CodeCraft or any OpenAI-compatible endpoint.", color = cs.onSurfaceVariant, fontSize = 14.sp)
                    vm.providers.forEach { p ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                Text(p.baseUrl.ifBlank { "No URL set" }, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1)
                                Text(
                                    (if (p.apiKey.isBlank()) "No key" else "Key •••• ${p.apiKey.takeLast(4)}") + " · " + p.defaultModel.ifBlank { "no model" },
                                    fontSize = 12.sp, color = cs.onSurfaceVariant
                                )
                            }
                            Switch(p.enabled, { c -> vm.saveProvider(p.copy(enabled = c)) })
                            IconButton({ editing = p }) { Icon(Icons.Filled.Edit, "Edit ${p.name}") }
                            IconButton({ deleting = p }) { Icon(Icons.Filled.Delete, "Remove ${p.name}") }
                        }
                    }
                    Button({ adding = true }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(8.dp)); Text("Add provider") }
                }

                Section("Model") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Auto model selection", fontWeight = FontWeight.SemiBold)
                            Text("Uses the selected provider first, skips providers that can't read your attachments, prefers a “code” model for the Coding tool, and falls back to the next provider on errors or rate limits (only before any text has been streamed).", fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                        Switch(vm.settings.autoModel, { c -> vm.update { copy(autoModel = c) } })
                    }
                    Text("Current: ${vm.modelLabel}", color = cs.primary, fontSize = 13.sp)
                    Text("Pick a specific model from the chip at the top of the chat.", fontSize = 12.sp, color = cs.onSurfaceVariant)
                }

                Section("Reply language") {
                    Choices(
                        listOf("auto" to "Match what I write", "en" to "English", "ur" to "اردو (Urdu)", "roman" to "Roman Urdu"),
                        vm.settings.replyLanguage
                    ) { v -> vm.update { copy(replyLanguage = v) } }
                }

                Section("Theme") {
                    Choices(listOf("dark" to "Dark", "light" to "Light", "system" to "Follow system"), vm.settings.theme) { v -> vm.update { copy(theme = v) } }
                }

                Section("Voice") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Speak AI replies aloud", Modifier.weight(1f))
                        Switch(vm.settings.ttsEnabled, { c -> vm.update { copy(ttsEnabled = c) } })
                    }
                    Text("Voice language (input and output)", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    Choices(listOf("en" to "English", "ur" to "اردو (Urdu)"), vm.settings.voiceLang) { v -> vm.update { copy(voiceLang = v) } }
                    OutlinedButton({ vm.speak(if (vm.settings.voiceLang == "ur") "آواز کی جانچ" else "Voice test") }) { Text("Test voice") }
                    Text("Microphone input uses Android's built-in speech recognizer (usually Google), and speech output uses the voices installed on your phone. If Urdu isn't available, install it in Android settings. Roman Urdu is read with the English voice.", fontSize = 12.sp, color = cs.onSurfaceVariant)
                }

                Section("Chat history") {
                    Text("${vm.chats.size} conversation(s) stored on this device.")
                    OutlinedButton({ confirmClear = true }, enabled = vm.chats.isNotEmpty()) { Text("Delete all chats") }
                }

                Section("Security & privacy") {
                    Text(
                        "• API keys are encrypted with a key held in the Android Keystore and are never written to logs or bundled in the app.\n" +
                            "• Keys stored on a phone are NOT equivalent to server-side secrets: a rooted or compromised device, or someone with your unlocked phone, may be able to use them. Use restricted/low-limit keys.\n" +
                            "• For providers that need protected server-side credentials, run your own secure backend and add it here as a custom OpenAI-compatible provider that holds the real secret.\n" +
                            "• Messages and attachments are sent only to the provider you select. No analytics or other services are contacted.\n" +
                            "• Chat history is stored in the app's private storage (not additionally encrypted).",
                        fontSize = 13.sp, color = cs.onSurfaceVariant, lineHeight = 19.sp
                    )
                }

                Section("About") {
                    Text("RAZA AI ASSISTANT v1.0.0", fontWeight = FontWeight.SemiBold)
                    Text("Native Android app built with Kotlin and Jetpack Compose. Bring your own API keys.", fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (adding) ProviderDialog(vm, null) { adding = false }
    editing?.let { p -> ProviderDialog(vm, p) { editing = null } }
    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null }, title = { Text("Remove ${p.name}?") },
            text = { Text("The provider and its saved API key will be deleted from this device.") },
            confirmButton = { TextButton({ vm.removeProvider(p.id); deleting = null }) { Text("Remove") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancel") } }
        )
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, title = { Text("Delete all chats?") },
        text = { Text("All conversations and attachments will be permanently deleted from this device.") },
        confirmButton = { TextButton({ vm.deleteAll(); confirmClear = false }) { Text("Delete all") } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } }
    )
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface.copy(alpha = 0.88f)),
        border = BorderStroke(1.dp, cs.outline.copy(alpha = 0.6f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = cs.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun Choices(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    options.forEach { (v, label) ->
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onSelect(v) }.padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) { RadioButton(v == selected, null); Spacer(Modifier.width(10.dp)); Text(label) }
    }
}

@Composable
private fun ProviderDialog(vm: AppViewModel, initial: Provider?, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: ProviderType.OPENAI_COMPATIBLE) }
    var url by remember { mutableStateOf(initial?.baseUrl ?: "") }
    var key by remember { mutableStateOf(initial?.apiKey ?: "") }
    var model by remember { mutableStateOf(initial?.defaultModel ?: "") }
    var models by remember { mutableStateOf(initial?.models ?: emptyList()) }
    var img by remember { mutableStateOf(initial?.supportsImages ?: false) }
    var pdf by remember { mutableStateOf(initial?.supportsPdf ?: false) }
    var showKey by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }
    val cs = MaterialTheme.colorScheme

    fun candidate() = Provider(id = initial?.id ?: newId(), name = name.trim(), type = type, baseUrl = url.trim(), apiKey = key.trim(),
        models = models, defaultModel = model.trim(), supportsImages = img, supportsPdf = pdf, enabled = initial?.enabled ?: true)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add provider" else "Edit provider") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (initial == null) {
                    Text("Start from a preset", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PRESETS.forEach { pr ->
                            AssistChip(onClick = {
                                name = pr.name; type = pr.type; url = pr.url; img = pr.images; pdf = pr.pdf; hint = pr.hint; msg = null
                            }, label = { Text(pr.name) })
                        }
                    }
                    hint?.let { Text(it, fontSize = 12.sp, color = cs.primary) }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == ProviderType.GEMINI, { type = ProviderType.GEMINI }, label = { Text("Gemini API") })
                    FilterChip(type == ProviderType.OPENAI_COMPATIBLE, { type = ProviderType.OPENAI_COMPATIBLE }, label = { Text("OpenAI-compatible") })
                }
                OutlinedTextField(url, { url = it }, label = { Text("Base URL (https://…)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    key, { key = it }, label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { IconButton({ showKey = !showKey }) { Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Show or hide key") } }
                )
                OutlinedTextField(model, { model = it }, label = { Text("Default model name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            busy = true; msg = null
                            vm.fetchModels(candidate()).onSuccess { list ->
                                models = list
                                msg = "Connected. Found ${list.size} models — tap one to use it."
                                if (model.isBlank()) model = list.firstOrNull().orEmpty()
                            }.onFailure { msg = vm.friendly(it) }
                            busy = false
                        }
                    },
                    enabled = !busy && url.startsWith("https://")
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Filled.CloudSync, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp)); Text("Test connection & fetch models")
                }
                msg?.let { Text(it, fontSize = 12.sp, color = if (it.startsWith("Connected")) cs.primary else cs.error) }
                if (models.isNotEmpty()) {
                    Column(Modifier.heightIn(max = 150.dp).verticalScroll(rememberScrollState())) {
                        models.forEach { m ->
                            Text(m, fontSize = 13.sp, color = if (m == model) cs.primary else cs.onSurface,
                                fontWeight = if (m == model) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.fillMaxWidth().clickable { model = m }.padding(vertical = 5.dp))
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Models accept images", Modifier.weight(1f)); Switch(img, { img = it }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Models accept PDFs", Modifier.weight(1f)); Switch(pdf, { pdf = it }) }
                Text("Only enable these if your chosen model really supports them; otherwise the provider will return an error.", fontSize = 11.sp, color = cs.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton({
                when {
                    name.isBlank() -> msg = "Enter a name."
                    !url.trim().startsWith("https://") -> msg = "Base URL must start with https://"
                    type == ProviderType.GEMINI && key.isBlank() -> msg = "Gemini needs an API key."
                    else -> {
                        val p = candidate()
                        vm.saveProvider(p.copy(models = (p.models + p.defaultModel).filter { it.isNotBlank() }.distinct()))
                        onDismiss()
                    }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}
