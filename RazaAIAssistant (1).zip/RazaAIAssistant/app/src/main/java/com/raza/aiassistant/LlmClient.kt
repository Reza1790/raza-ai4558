package com.raza.aiassistant

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.*
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

class LlmException(message: String, val retryable: Boolean = false) : Exception(message)

/**
 * Talks to real provider APIs only. Endpoints come from the user's provider config:
 *  - GEMINI: {base}/models/{model}:streamGenerateContent?alt=sse  (key in x-goog-api-key header)
 *  - OPENAI_COMPATIBLE: {base}/chat/completions with stream=true  (key as Bearer token)
 */
object LlmClient {
    class Turn(val role: String, val text: String, val files: List<Attachment>)

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
    private val json = Json { ignoreUnknownKeys = true }
    private val JSON_MT = "application/json".toMediaType()

    private fun JsonElement?.obj() = this as? JsonObject
    private fun JsonElement?.arr() = this as? JsonArray
    private fun JsonElement?.str() = (this as? JsonPrimitive)?.contentOrNull

    private fun base(p: Provider) = p.baseUrl.trim().trimEnd('/')
    private fun b64(a: Attachment) = Base64.encodeToString(File(a.path).readBytes(), Base64.NO_WRAP)

    fun stream(p: Provider, model: String, system: String, turns: List<Turn>): Flow<String> = callbackFlow {
        var call: Call? = null
        val job = launch(Dispatchers.IO) {
            try {
                val c = http.newCall(buildRequest(p, model, system, turns))
                call = c
                c.execute().use { resp ->
                    if (!resp.isSuccessful) throw httpError(resp.code, resp.body?.string())
                    val body = resp.body ?: throw LlmException("Empty response from server.", true)
                    val ct = resp.header("Content-Type").orEmpty()
                    if (!ct.contains("event-stream") && p.type == ProviderType.OPENAI_COMPATIBLE) {
                        // Server ignored streaming: parse a normal JSON completion.
                        val text = parseFull(body.string())
                        if (text.isNotEmpty()) send(text)
                    } else {
                        val src = body.source()
                        while (true) {
                            val line = src.readUtf8Line() ?: break
                            if (!line.startsWith("data:")) continue
                            val data = line.substring(5).trim()
                            if (data == "[DONE]") break
                            if (data.isEmpty()) continue
                            val t = parseChunk(p.type, data)
                            if (t.isNotEmpty()) send(t)
                        }
                    }
                }
                close()
            } catch (e: Throwable) {
                close(e)
            }
        }
        awaitClose { call?.cancel(); job.cancel() }
    }

    fun listModels(p: Provider): List<String> {
        val gemini = p.type == ProviderType.GEMINI
        val rb = Request.Builder().url(if (gemini) "${base(p)}/models?pageSize=200" else "${base(p)}/models")
        val key = p.apiKey.trim()
        if (gemini) rb.header("x-goog-api-key", key) else if (key.isNotEmpty()) rb.header("Authorization", "Bearer $key")
        return http.newCall(rb.build()).execute().use { r ->
            if (!r.isSuccessful) throw httpError(r.code, r.body?.string())
            val root = runCatching { json.parseToJsonElement(r.body?.string().orEmpty()).obj() }.getOrNull()
                ?: throw LlmException("This endpoint did not return a model list. You can type a model name manually.")
            val names: List<String> = if (gemini) {
                root["models"].arr().orEmpty()
                    .filter { m -> m.obj()?.get("supportedGenerationMethods").arr()?.any { it.str() == "generateContent" } == true }
                    .mapNotNull { it.obj()?.get("name").str()?.removePrefix("models/") }
            } else {
                root["data"].arr().orEmpty().mapNotNull { it.obj()?.get("id").str() }
            }
            names.sorted()
        }
    }

    private fun buildRequest(p: Provider, model: String, system: String, turns: List<Turn>): Request {
        val key = p.apiKey.trim()
        return if (p.type == ProviderType.GEMINI) {
            Request.Builder()
                .url("${base(p)}/models/$model:streamGenerateContent?alt=sse")
                .header("x-goog-api-key", key)
                .post(geminiBody(system, turns).toRequestBody(JSON_MT))
                .build()
        } else {
            Request.Builder()
                .url("${base(p)}/chat/completions")
                .apply { if (key.isNotEmpty()) header("Authorization", "Bearer $key") }
                .post(openAiBody(model, system, turns).toRequestBody(JSON_MT))
                .build()
        }
    }

    private fun geminiBody(system: String, turns: List<Turn>): String = buildJsonObject {
        if (system.isNotBlank()) put("systemInstruction", buildJsonObject {
            put("parts", buildJsonArray { add(buildJsonObject { put("text", system) }) })
        })
        put("contents", buildJsonArray {
            for (t in turns) add(buildJsonObject {
                put("role", if (t.role == "user") "user" else "model")
                put("parts", buildJsonArray {
                    for (f in t.files) add(buildJsonObject {
                        put("inline_data", buildJsonObject { put("mime_type", f.mime); put("data", b64(f)) })
                    })
                    add(buildJsonObject { put("text", t.text.ifBlank { " " }) })
                })
            })
        })
    }.toString()

    private fun openAiBody(model: String, system: String, turns: List<Turn>): String = buildJsonObject {
        put("model", model)
        put("stream", true)
        put("messages", buildJsonArray {
            if (system.isNotBlank()) add(buildJsonObject { put("role", "system"); put("content", system) })
            for (t in turns) add(buildJsonObject {
                put("role", t.role)
                if (t.files.isEmpty()) put("content", t.text.ifBlank { " " })
                else put("content", buildJsonArray {
                    add(buildJsonObject { put("type", "text"); put("text", t.text.ifBlank { "Describe this." }) })
                    for (f in t.files) add(buildJsonObject {
                        put("type", "image_url")
                        put("image_url", buildJsonObject { put("url", "data:${f.mime};base64,${b64(f)}") })
                    })
                })
            })
        })
    }.toString()

    private fun parseChunk(type: ProviderType, data: String): String {
        val root = json.parseToJsonElement(data).obj() ?: return ""
        root["error"]?.let { throw LlmException("Provider error: ${it.obj()?.get("message").str() ?: "unknown"}") }
        if (type == ProviderType.GEMINI) {
            val cands = root["candidates"].arr()
            if (cands.isNullOrEmpty()) {
                val block = root["promptFeedback"].obj()?.get("blockReason").str()
                if (block != null) throw LlmException("The provider's safety filter blocked this prompt ($block).")
                return ""
            }
            return cands[0].obj()?.get("content").obj()?.get("parts").arr().orEmpty().joinToString("") { part ->
                val o = part.obj()
                if ((o?.get("thought") as? JsonPrimitive)?.booleanOrNull == true) "" else o?.get("text").str().orEmpty()
            }
        }
        return root["choices"].arr()?.firstOrNull().obj()?.get("delta").obj()?.get("content").str().orEmpty()
    }

    private fun parseFull(body: String): String {
        val root = runCatching { json.parseToJsonElement(body).obj() }.getOrNull() ?: return ""
        root["error"]?.let { throw LlmException("Provider error: ${it.obj()?.get("message").str() ?: "unknown"}") }
        return root["choices"].arr()?.firstOrNull().obj()?.get("message").obj()?.get("content").str().orEmpty()
    }

    private fun httpError(code: Int, body: String?): LlmException {
        val detail = runCatching {
            val e = json.parseToJsonElement(body.orEmpty()).obj()?.get("error")
            e.obj()?.get("message").str() ?: e.str()
        }.getOrNull()?.take(300)?.let { " — $it" } ?: ""
        return when (code) {
            400 -> LlmException("The provider rejected the request (400)$detail")
            401, 403 -> LlmException("API key rejected or not permitted ($code)$detail. Check the key in Settings → Providers.")
            404 -> LlmException("Endpoint or model not found (404)$detail. Check the base URL and model name.")
            408, 425, 429 -> LlmException("Rate limit or quota reached ($code)$detail. Wait a moment, or switch model/provider.", true)
            in 500..599 -> LlmException("The provider had a server error ($code)$detail.", true)
            else -> LlmException("Request failed (HTTP $code)$detail")
        }
    }
}
