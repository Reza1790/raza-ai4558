package com.raza.aiassistant

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.serialization.Serializable
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

@Serializable
enum class ProviderType { GEMINI, OPENAI_COMPATIBLE }

@Serializable
data class Provider(
    val id: String = newId(),
    val name: String,
    val type: ProviderType,
    val baseUrl: String,
    val apiKey: String = "",
    val models: List<String> = emptyList(),
    val defaultModel: String = "",
    val supportsImages: Boolean = false,
    val supportsPdf: Boolean = false,
    val enabled: Boolean = true,
)

data class Preset(
    val name: String, val type: ProviderType, val url: String,
    val images: Boolean, val pdf: Boolean, val hint: String,
)

val PRESETS = listOf(
    Preset("Google Gemini", ProviderType.GEMINI, "https://generativelanguage.googleapis.com/v1beta", true, true,
        "Create a key in Google AI Studio, paste it here, then tap “Fetch models”."),
    Preset("OpenAI", ProviderType.OPENAI_COMPATIBLE, "https://api.openai.com/v1", true, false,
        "Uses the standard Chat Completions API."),
    Preset("CodeCraft", ProviderType.OPENAI_COMPATIBLE, "", false, false,
        "Enter the exact base URL from CodeCraft's documentation. This only works if CodeCraft exposes an OpenAI-compatible /chat/completions API. If its format differs, send me the spec and a dedicated adapter can be added."),
    Preset("Custom", ProviderType.OPENAI_COMPATIBLE, "", false, false,
        "Any OpenAI-compatible HTTPS endpoint (OpenRouter, Groq, your own gateway…). The base URL usually ends in /v1."),
)

@Serializable
data class Attachment(val name: String, val mime: String, val path: String)

@Serializable
data class Message(
    val id: String = newId(),
    val role: String, // "user" | "assistant"
    val text: String,
    val attachments: List<Attachment> = emptyList(),
    val model: String = "",
    val isError: Boolean = false,
    val time: Long = System.currentTimeMillis(),
)

@Serializable
data class Chat(
    val id: String = newId(),
    val title: String = "New chat",
    val tool: String = "general",
    val messages: List<Message> = emptyList(),
    val updated: Long = System.currentTimeMillis(),
)

@Serializable
data class Settings(
    val theme: String = "dark",          // dark | light | system
    val replyLanguage: String = "auto",  // auto | en | ur | roman
    val autoModel: Boolean = false,
    val activeProviderId: String = "",
    val activeModel: String = "",
    val ttsEnabled: Boolean = false,
    val voiceLang: String = "en",        // en | ur
)

enum class Tool(val id: String, val label: String, val icon: ImageVector, val blurb: String, val prompt: String) {
    GENERAL("general", "Assistant", Icons.Filled.AutoAwesome, "Ask anything in English, اردو or Roman Urdu",
        "You are RAZA AI, a helpful, accurate and concise general-purpose assistant."),
    CODING("coding", "Coding", Icons.Filled.Code, "Write, explain and debug code",
        "You are RAZA AI Coding Assistant, a senior software engineer. Give correct, idiomatic, working code with brief explanations. State assumptions and mention edge cases."),
    DOCUMENT("document", "Documents", Icons.Filled.Description, "Attach a PDF or text file to summarize or question it",
        "You are RAZA AI Document Assistant. Analyze attached documents carefully, summarize faithfully, extract key facts, and answer only from the document unless asked otherwise. Say when something is not in the document."),
    IMAGE("image", "Image", Icons.Filled.Image, "Attach an image and ask about it",
        "You are RAZA AI Image Assistant. Describe and analyze attached images accurately, read visible text, and answer questions about them. Say when something is unclear in the image."),
    STUDY("study", "Study", Icons.Filled.School, "Learn topics step by step",
        "You are RAZA AI Study Assistant, a patient tutor. Explain step by step, use simple examples, check understanding with short questions, and adapt to the student's level."),
    WRITING("writing", "Writing", Icons.Filled.Edit, "Draft, rewrite and polish text",
        "You are RAZA AI Writing Assistant. Draft, rewrite, proofread and improve text while preserving the author's meaning and requested tone. Offer concise alternatives when useful.");

    companion object {
        fun byId(id: String): Tool = entries.firstOrNull { it.id == id } ?: GENERAL
    }
}
