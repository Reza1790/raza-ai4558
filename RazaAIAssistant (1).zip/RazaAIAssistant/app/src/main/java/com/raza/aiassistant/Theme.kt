package com.raza.aiassistant

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

object Raza {
    val Cyan = Color(0xFF38E1FF)
    val Violet = Color(0xFF8B5CF6)
    val Pink = Color(0xFFEC4899)
    val Brand = Brush.linearGradient(listOf(Violet, Cyan))
}

private val DarkScheme = darkColorScheme(
    primary = Raza.Cyan, onPrimary = Color(0xFF00212A),
    secondary = Raza.Violet, tertiary = Raza.Pink,
    background = Color(0xFF070A14), onBackground = Color(0xFFE8ECFF),
    surface = Color(0xFF0E1426), onSurface = Color(0xFFE8ECFF),
    surfaceVariant = Color(0xFF171F3A), onSurfaceVariant = Color(0xFFA9B3D6),
    outline = Color(0xFF2A3562),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF6D3BE0), onPrimary = Color.White,
    secondary = Color(0xFF0891B2), tertiary = Raza.Pink,
    background = Color(0xFFF4F6FF), onBackground = Color(0xFF12162B),
    surface = Color.White, onSurface = Color(0xFF12162B),
    surfaceVariant = Color(0xFFE8EBFB), onSurfaceVariant = Color(0xFF50587A),
    outline = Color(0xFFC5CBEA),
)

@Composable
fun RazaTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = Typography(), content = content)
}

@Composable
fun appBackground(): Brush {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) Brush.verticalGradient(listOf(Color(0xFF0D1236), Color(0xFF070A14), Color(0xFF0A0719)))
    else Brush.verticalGradient(listOf(Color(0xFFE6ECFF), Color(0xFFF6F7FF), Color(0xFFF1EBFF)))
}
