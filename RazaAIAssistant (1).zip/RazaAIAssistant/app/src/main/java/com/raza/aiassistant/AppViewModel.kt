package com.raza.aiassistant

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Storage(app)
    val tts = TtsManager(app)
    private var job: Job? = null

    var settings by mutableStateOf(store.loadSettings())
    var providers by mutableStateOf(store.loadProviders())
    var chats by mutableStateOf(store.loadChats())
    var currentId by mutableStateOf<String?>(null)
    var streaming by mutableStateOf(false)
    var streamText by mutableStateOf("")
    var streamingChatId by mutableStateOf<String?>(null)
    var pending by mutableStateOf<List<Attachment>>(emptyList())
    var tool by mutableStateOf(Tool.GENERAL)
    var lastUsedModel by mutableStateOf("")
    var notice by mutableStateOf<String?>(null)
    var query by mutableStateOf("")

    val current: Chat? get() = chats.firstOrNull { it.id == currentId }
    val activeProvider: Provider? get() = providers.firstOrNull { it.id == settings.activeProviderId }
    val hasReadyProvider: Boolean get() = providers.any { isReady(it) }

    val modelLabel: String
        get() {
            if (settings.autoModel) return if (lastUsedModel.isBlank()) "Auto" else "Auto · $lastUsedModel"
            val p = activeProvider ?: return "No model selected"
            val m = settings.activeModel.ifBlank { p.defaultModel }
            return if (m.isBlank()) p.name else "${p.name} · $m"
        }

    val filteredChats: List<Chat>
        get() {
            val q = query.trim()
            if (q.isEmpty()) return chats
            return chats.filter { c -> c.title.contains(q, true) || c.messages.any { it.text.contains(q, true) } }
        }

    private fun isReady(p: Provider) =
        p.enabled && p.baseUrl.isNotBlank() && (p.type != ProviderType.GEMINI || p.apiKey.isNotBlank())

    // ---------- settings & providers ----------
    fun update(f: Settings.() -> Settings) {
        settings = settings.f()
        store.saveSettings(settings)
    }

    fun saveProvider(p: Provider) {
        val l = providers.toMutableList()
        val i = l.indexOfFirst { it.id == p.id }
        if (i >= 0) l[i] = p else l.add(p)
        providers = l
        store.saveProviders(l)
        if (providers.none { it.id == settings.activeProviderId }) update { copy(activeProviderId = p.id, activeModel = p.defaultModel) }
    }

    fun removeProvider(id: String) {
        providers = providers.filter { it.id != id }
        store.saveProviders(providers)
        if (settings.activeProviderId == id) {
            val n = providers.firstOrNull()
            update { copy(activeProviderId = n?.id.orEmpty(), activeModel = n?.defaultModel.orEmpty()) }
        }
    }

    fun selectModel(providerId: String, model: String) = update { copy(activeProviderId = providerId, activeModel = model) }

    suspend fun fetchModels(p: Provider): Result<List<String>> =
        withContext(Dispatchers.IO) { runCatching { LlmClient.listModels(p) } }

    // ---------- chats ----------
    private fun putChat(c: Chat) {
        store.saveChat(c)
        chats = (listOf(c) + chats.filter { it.id != c.id }).sortedByDescending { it.updated }
    }

    fun newChat() { currentId = null; pending = emptyList() }

    fun open(id: String) {
        currentId = id
        pending = emptyList()
        current?.let { tool = Tool.byId(it.tool) }
    }

    fun selectTool(t: Tool) {
        tool = t
        current?.let { putChat(it.copy(tool = t.id)) }
    }

    fun rename(id: String, title: String) {
        chats.firstOrNull { it.id == id }?.let { c -> putChat(c.copy(title = title.trim().ifBlank { c.title })) }
    }

    fun delete(id: String) {
        if (streamingChatId == id) job?.cancel()
        chats.firstOrNull { it.id == id }?.let { store.deleteChat(it) }
        chats = chats.filter { it.id != id }
        if (currentId == id) currentId = null
    }

    fun deleteAll() {
        job?.cancel()
        chats.forEach { store.deleteChat(it) }
        chats = emptyList(); currentId = null
    }

    fun addAttachments(uris: List<Uri>) {
        viewModelScope.launch {
            for (u in uris) {
                if (pending.size >= 5) { notice = "You can attach up to 5 files per message."; break }
                runCatching { withContext(Dispatchers.IO) { store.importAttachment(u) } }
                    .onSuccess { pending = pending + it }
                    .onFailure { notice = it.message ?: "Could not attach file." }
            }
        }
    }

    fun removePending(a: Attachment) {
        pending = pending - a
        File(a.path).delete()
    }

    // ---------- sending ----------
    fun send(text: String) {
        if (streaming) return
        val t = text.trim()
        if (t.isEmpty() && pending.isEmpty()) return
        val base = current ?: Chat(tool = tool.id)
        if (tool == Tool.IMAGE) {
            val hasImage = pending.any { it.mime.startsWith("image/") } || base.messages.any { m -> m.attachments.any { it.mime.startsWith("image/") } }
            if (!hasImage) { notice = "The Image tool needs an image. Tap the paperclip to attach one."; return }
        }
        tts.stop()
        val msg = Message(role = "user", text = t, attachments = pending)
        val title = if (base.messages.isEmpty()) (t.ifBlank { pending.first().name }).replace('\n', ' ').take(40) else base.title
        val chat = base.copy(messages = base.messages + msg, title = title, updated = System.currentTimeMillis(), tool = tool.id)
        pending = emptyList()
        currentId = chat.id
        putChat(chat)
        generate(chat)
    }

    fun regenerate() {
        if (streaming) return
        val c = current ?: return
        val idx = c.messages.indexOfLast { it.role == "user" }
        if (idx < 0) return
        val trimmed = c.copy(messages = c.messages.take(idx + 1))
        putChat(trimmed)
        generate(trimmed)
    }

    fun stop() { job?.cancel(); tts.stop() }

    private fun modelFor(p: Provider, t: Tool): String {
        val base = if (p.id == settings.activeProviderId && settings.activeModel.isNotBlank()) settings.activeModel else p.defaultModel
        if (!settings.autoModel) return base
        if (t == Tool.CODING) p.models.firstOrNull { it.contains("code", true) }?.let { return it }
        return base.ifBlank { p.models.firstOrNull().orEmpty() }
    }

    private fun pick(img: Boolean, pdf: Boolean, t: Tool): Pair<List<Pair<Provider, String>>, String?> {
        val ready = providers.filter { isReady(it) }
        val sel = ready.firstOrNull { it.id == settings.activeProviderId }
        fun capable(p: Provider) = (!img || p.supportsImages) && (!pdf || p.supportsPdf)
        if (providers.isEmpty()) return emptyList<Pair<Provider, String>>() to "No AI provider is configured. Open Settings → Providers and add one with your API key."
        if (!settings.autoModel) {
            val p = sel ?: return emptyList<Pair<Provider, String>>() to "The selected provider is missing an API key or URL. Open Settings → Providers."
            val m = modelFor(p, t)
            if (m.isBlank()) return emptyList<Pair<Provider, String>>() to "No model is chosen for ${p.name}. Tap the model chip at the top, or type a model name in Settings → Providers."
            if (img && !p.supportsImages) return emptyList<Pair<Provider, String>>() to "${p.name} is not marked as image-capable. Choose a vision-capable provider/model, enable “Supports images” for it in Settings, or turn on Auto model."
            if (pdf && !p.supportsPdf) return emptyList<Pair<Provider, String>>() to "${p.name} cannot read PDF files directly. Use a provider that supports PDFs (e.g. Gemini), or attach the text instead."
            return listOf(p to m) to null
        }
        val ordered = (listOfNotNull(sel) + ready.filter { it.id != sel?.id }).filter { capable(it) && modelFor(it, t).isNotBlank() }
        if (ordered.isEmpty()) return emptyList<Pair<Provider, String>>() to "Auto model found no configured provider that can handle this request (check API keys, model names, and image/PDF support in Settings)."
        return ordered.map { it to modelFor(it, t) } to null
    }

    private fun systemPrompt(t: Tool): String {
        val lang = when (settings.replyLanguage) {
            "en" -> "Always reply in English."
            "ur" -> "Always reply in Urdu using Urdu script (اردو)."
            "roman" -> "Always reply in Roman Urdu (Urdu written with Latin letters)."
            else -> "Reply in the language and script the user writes in: English, Urdu script, or Roman Urdu."
        }
        return "${t.prompt}\n$lang\nFormat answers with Markdown. Put code in fenced code blocks with a language tag."
    }

    private fun buildTurns(chat: Chat): List<LlmClient.Turn> = chat.messages.filter { !it.isError }.map { m ->
        val files = mutableListOf<Attachment>()
        var text = m.text
        for (a in m.attachments) {
            if (a.mime.startsWith("image/") || a.mime == "application/pdf") files += a
            else text += "\n\n--- File: ${a.name} ---\n" + File(a.path).readText().take(200_000)
        }
        LlmClient.Turn(m.role, text, files)
    }

    private fun generate(chat: Chat) {
        val img = chat.messages.any { m -> m.attachments.any { it.mime.startsWith("image/") } }
        val pdf = chat.messages.any { m -> m.attachments.any { it.mime == "application/pdf" } }
        val t = Tool.byId(chat.tool)
        val (cands, problem) = pick(img, pdf, t)
        if (cands.isEmpty()) {
            addAssistant(chat.id, Message(role = "assistant", text = problem ?: "No model available.", isError = true))
            return
        }
        streaming = true; streamText = ""; streamingChatId = chat.id
        job = viewModelScope.launch {
            var cur: Pair<Provider, String>? = null
            var err: Throwable? = null
            var stopped = false
            try {
                for ((p, m) in cands) {
                    cur = p to m; err = null; streamText = ""
                    try {
                        val turns = withContext(Dispatchers.IO) { buildTurns(chat) }
                        LlmClient.stream(p, m, systemPrompt(t), turns).collect { streamText += it }
                        break
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        err = e
                        if (streamText.isNotEmpty()) break // partial answer exists: don't switch model mid-reply
                    }
                }
            } catch (e: CancellationException) {
                stopped = true
            }
            withContext(NonCancellable) { finish(chat.id, cur, err, stopped) }
        }
    }

    private fun addAssistant(id: String, m: Message) {
        chats.firstOrNull { it.id == id }?.let { c -> putChat(c.copy(messages = c.messages + m, updated = System.currentTimeMillis())) }
    }

    private fun finish(id: String, used: Pair<Provider, String>?, err: Throwable?, stopped: Boolean) {
        val text = streamText
        streaming = false; streamText = ""; streamingChatId = null
        val chat = chats.firstOrNull { it.id == id } ?: return
        val label = used?.let { "${it.first.name} · ${it.second}" } ?: ""
        val msg: Message? = when {
            text.isNotEmpty() -> Message(role = "assistant", text = if (err != null) "$text\n\n⚠️ ${friendly(err)}" else text, model = label)
            err != null -> Message(role = "assistant", text = friendly(err), isError = true)
            stopped -> null
            else -> Message(role = "assistant", text = "The model returned an empty response. Try again or pick a different model.", isError = true)
        }
        if (msg != null) putChat(chat.copy(messages = chat.messages + msg, updated = System.currentTimeMillis()))
        if (err == null && text.isNotEmpty()) lastUsedModel = label
        if (msg != null && !msg.isError && err == null && !stopped && settings.ttsEnabled) speak(text)
    }

    fun friendly(e: Throwable): String = when (e) {
        is LlmException -> e.message ?: "Request failed."
        is UnknownHostException -> "Can't reach the server. Check your internet connection and the endpoint URL."
        is SocketTimeoutException -> "The request timed out. Try again."
        is IllegalArgumentException -> "Invalid endpoint URL. Check the base URL in Settings → Providers."
        is IOException -> "Network error: ${e.message ?: "connection failed"}"
        else -> "Unexpected error: ${e.message ?: e.javaClass.simpleName}"
    }

    fun speak(text: String) { tts.speak(text, settings.voiceLang)?.let { notice = it } }

    override fun onCleared() { tts.shutdown() }
}
