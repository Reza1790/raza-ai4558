package com.raza.aiassistant

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Wraps Android's on-device TextToSpeech engine. Returns a human-readable error instead of failing silently. */
class TtsManager(ctx: Context) {
    private var ready = false
    private var tts: TextToSpeech? = TextToSpeech(ctx.applicationContext) { status -> ready = status == TextToSpeech.SUCCESS }

    fun speak(text: String, lang: String): String? {
        val t = tts ?: return "Text-to-speech is unavailable."
        if (!ready) return "Text-to-speech engine is not ready yet or not installed on this device."
        val loc = if (lang == "ur") Locale("ur", "PK") else Locale.US
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            return "No ${if (lang == "ur") "Urdu" else "English"} voice is installed. Add one in Android Settings → Text-to-speech output."
        }
        t.speak(clean(text), TextToSpeech.QUEUE_FLUSH, null, "raza")
        return null
    }

    fun stop() { tts?.stop() }
    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }

    private fun clean(s: String) = s
        .replace(Regex("```[\\s\\S]*?```"), " code block omitted. ")
        .replace(Regex("[*#`_>|]"), "")
        .take(3900)
}
